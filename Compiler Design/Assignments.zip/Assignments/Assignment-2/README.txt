TEAM  Details:
Ashutosh Chauhan, S20180010017
Mohammed Mohsin Ali, S20180010105
T. Vishruth, S20180010175
L. Praneeth, S20180010094

VALID VARIABLES: Single Uppercase letter
VALID TERMINALS: Single Lowercase letter

Input File Format:
```
S -> Ab
A -> c
```

Note: 'S' is the start symbol
One production per line

Steps to Run:
```
flex++ ll1.lex
g++ lex.yy.cc
./a.out < input.txt
```

